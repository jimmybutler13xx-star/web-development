# Web Development Roadmap — Completed Tasks

All 8 tasks from the Level 1–3 roadmap, each in its own runnable folder.

## Level 1 (Basic)
| Folder | Task | How to view |
|---|---|---|
| `level1-task1-static-website/` | Multi-page static site (home, about, contact) with nav bar, footer, responsive media queries | Open `index.html` in a browser |
| `level1-task2-portfolio-page/` | Single-page portfolio with intro, projects, skills, contact sections, custom fonts & animations | Open `index.html` in a browser |
| `level1-task3-js-basics/` | Dropdown menu, modal dialog, and validated sign-up form built with vanilla JS | Open `index.html` in a browser |

## Level 2 (Intermediate)
| Folder | Task | How to view |
|---|---|---|
| `level2-task1-flexbox-grid/` | Responsive layout: Flexbox header/hero, CSS Grid photo gallery and blog layout, adapts across desktop/tablet/mobile | Open `index.html` in a browser |
| `level2-task2-todo-app/` | To-do list app — add/delete/complete tasks, filters, persisted to `localStorage` | Open `index.html` in a browser |
| `level2-task3-react-calculator/` | Component-based React calculator (components, props, state) via CDN — no build step required | Open `index.html` in a browser |

## Level 3 (Advanced)
| Folder | Task | How to run |
|---|---|---|
| `level3-task1-fullstack-crud/` | Full-stack CRUD task manager: Express REST API backend + React frontend | See its own `README.md` — run backend with `npm install && npm start`, then open `frontend/index.html` |
| `level3-task2-auth-system/` | User authentication: registration, login, bcrypt password hashing, JWT-protected routes | See its own `README.md` — run with `npm install && npm start`, then open `client.html` |

## Notes
- Levels 1 and 2 are pure front-end and need no installation — just open the `index.html` files.
- Level 3 tasks are full-stack: they need Node.js installed and `npm install` run inside each
  task's folder before starting the server (see each folder's `README.md` for exact commands).
- Both Level 3 backends use a local JSON file as a lightweight database so they run with zero
  external setup; each README explains exactly how to swap in MongoDB or PostgreSQL instead.
