# Task Manager — Full-Stack CRUD Application

A full-stack CRUD app: Express REST API backend + React frontend.

## Structure
- `backend/` — Express server, REST API (`/api/tasks`), JSON-file data store (`db.json`)
- `frontend/` — Single-page React app (loaded via CDN, no build step) that consumes the API

## Run the backend
```bash
cd backend
npm install
npm start
```
The API runs at `http://localhost:4000`. Try `GET http://localhost:4000/api/tasks` in a browser.

## Run the frontend
Just open `frontend/index.html` directly in your browser (or serve it with any static
server, e.g. `npx serve frontend`). It's a self-contained React app using CDN scripts,
so no npm install is needed for the frontend.

**Important:** the backend must be running first, or the frontend will show a
"Could not reach the API" message.

## Swapping in a real database
The backend currently stores data in `backend/db.json` for simplicity. The route handlers
in `server.js` only call two functions — `readDB()` and `writeDB()` — so switching to a real
database means replacing just those two functions:

- **MongoDB**: use Mongoose, define a `Task` schema/model, and replace
  `readDB()/writeDB()` calls with `Task.find()`, `Task.create()`, `Task.findByIdAndUpdate()`,
  `Task.findByIdAndDelete()`.
- **PostgreSQL**: use the `pg` package with a connection `Pool`, and replace the same
  calls with parameterized `SELECT / INSERT / UPDATE / DELETE` queries against a `tasks` table.

## API Reference
| Method | Route             | Description         |
|--------|-------------------|----------------------|
| GET    | /api/tasks        | List all tasks       |
| GET    | /api/tasks/:id    | Get one task         |
| POST   | /api/tasks        | Create a task        |
| PUT    | /api/tasks/:id    | Update a task        |
| DELETE | /api/tasks/:id    | Delete a task        |
